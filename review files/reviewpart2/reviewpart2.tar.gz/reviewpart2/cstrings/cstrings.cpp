/* Demo for 
* c strings
*/

#include <iostream>
#include <cstring>

using namespace std;


const int MAX_CHAR = 200; // the max size of a string

int main() 
{
	char line1[MAX_CHAR+1];
	char line2[MAX_CHAR+1];
	char line3[MAX_CHAR+1];
	char line4[] = "Pop goes the Weasel!"; 
	
	// input
	cout << "Enter 3 lines:" << endl;
	cin.get(line1,MAX_CHAR,'\n');
	cin.ignore(MAX_CHAR, '\n');
	cin.get(line2,MAX_CHAR,'\n');
	cin.ignore(MAX_CHAR, '\n');
	cin.get(line3,MAX_CHAR,'\n');
	cin.ignore(MAX_CHAR, '\n');
	
	// output
	cout << "you entered: " << endl;
	cout << line1 << endl;
	cout << line2 << endl;
	cout << line3 << endl << endl;
	
	// length
    cout << " The length of line1 is " << strlen(line1) << endl;
	cout << " The length of line2 is " << strlen(line2) << endl;
	cout << " The length of line3 is " << strlen(line3) << endl;
	cout << " The length of line4 is " << strlen(line4
	) << endl;
	
	//compare
	cout << endl << "comparing line1 and line3" << endl;
	if(strcmp(line1, line3) == 0)
	{
		cout << "line1 and line3 are equal." << endl;
	}
	else if(strcmp(line1, line3) > 0)
	{
		cout << "line1 is after line3 in order." << endl;
	}
	else  //strcmp(line1, line3) < 0
	{
		cout << "line1 is before line3 in order." << endl;
	}
	
	// copy
	cout << endl << "original line4 is: " << endl;
	cout << line4 << endl;
	cout << "copying line4 to line2, line2 is now: " << endl;
	strcpy(line2, line4);
	cout << line2 << endl;

	
	return 0;

}

