/* Division Table by Dona Hertel
 * Demo for cout manipulators
 * and printing in table format.
 * Calculates a division
 * table from 1 to 12
 * 
 */
 
#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

int main()
{	
	int n;
	cout << "how many decimal places?" << endl;
	cin >> n;
	cout << setprecision(n) << fixed;
	// print header for table: Note the lack of a 'endl' 
	// in the cout statement here.  This will keep printing
	// on the same line
	for(float i=1; i<13; i++)
	{
	    cout << setw(n+4) << i;
	}
	cout << endl;  // Now, we move down one line and print some dashes
	cout << "------------------------------------------------------------------" << endl;
	// the outer for loop prints rows
	for(float i=1; i<13; i++)
	{
		// the inner for loop prints columns
		for(float j=1; j<13; j++)
		{
		    cout << setw(n+4) << i/j;  // again, note the lack of 'endl'
		}
	    cout << endl;  // move to next row
	}
	
	return 0;
}

