/* Prime Numbers up to 10
 * Demo uses a switch statement
 * print out whether or not a number is
 * prime.  Numbers outside of 0 to 10
 * print an error message.
 */
 
#include <iostream>

using namespace std;

int main() 
{
   int number;
   
   cout << "Enter a number from 1 to 10" << endl;
   cin >> number;
   
   switch(number)
   {
	   case 1:
	   case 2:
	   case 3:
	   case 5:
	   case 7:  cout << number << " is a prime number." << endl;
	            break;
	   case 4:
	   case 6:
	   case 8:
	   case 9:
	   case 10: cout << number << " is NOT a prime number." << endl;
	            break;
	   default: cout << "Not a number between 1 and 10!" << endl;
   }
	
   return 0;
}

