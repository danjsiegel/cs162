/* Demo for 
 * enum types
 */

#include <iostream>

using namespace std;

//here is where I define by enum type
enum Shape{CIRCLE, SQUARE, TRIANGLE};

const float PI = 3.1416;


int main() 
{
	float num = 5.0;
	float area = 0.0;
    Shape choice;  // this is where I create the variable
    int ch;
    
    cout << "Pick a Shape:" << endl;
    cout <<	"0 - circle" << endl;
    cout <<	"1 - triangle" << endl;
    cout <<	"2 - square" << endl;
    
    //unfortunately cant directly input a enum type
    cin >> ch; // so get input as a integer
	choice = (Shape) ch; // typecast to a Shape type
	
	
	switch(choice)
	{
		case CIRCLE: area = PI*num*num;
		             break;
		case SQUARE: area = num*num;
		             break;
		case TRIANGLE: area = 0.5*num*num;
	 }
	
	cout << "area is " << area << endl;
	
	// note that I can't print the named values of the
	// enum type, just the numerical values
	
	cout << "Printing shape variable " << endl;
	cout << choice << endl;
	cout << "which is a ";
	switch(choice)
	{
		case CIRCLE: cout << "circle." << endl;
		             break;
		case SQUARE: cout << "square." << endl;
		             break;
		case TRIANGLE: cout << "triangle." << endl;
		             break;
	 }
	return 0;
	
}

