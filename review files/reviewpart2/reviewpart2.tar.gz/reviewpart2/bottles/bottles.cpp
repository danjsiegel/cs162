/* Bottles of Beer on the Wall Song
 * Demo of one for loop
 */ 
 
#include <iostream>

using namespace std;

int main()
{	
	int number;
	
	cout << "How many bottles to start with: " << endl;
	cin >> number;
	
	for(int i=number; i>1;)
	{
		cout << i << " Bottles of Beer on the Wall." << endl;
		cout << i << " Bottles of Beer." << endl;
		cout << "Take one Down; Pass it Around. " << endl;
		i--;
		if(i == 1)
		{
			cout << "1 Bottle of Beer on the Wall." << endl;
        }
        else
        {
		     cout << i << " Bottles of Beer on the Wall." << endl;
		}
		cout << endl;
	}
	 
	cout << "1 Bottle of Beer on the Wall." << endl;
	cout << "1 Bottle of Beer."<< endl;
	cout << "Take it Down; Pass it Around. " << endl;
	cout << "No More Bottles of Beer on the Wall." << endl;
	cout << "END OF SONG" << endl;
	
	return 0;
}
